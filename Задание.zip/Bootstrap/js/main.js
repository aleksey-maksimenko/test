$(document).ready(function() {
  $("body").css("min-height", $(window).height());
  $(".level-1, .level-2, .level-3, .level-4").hide();
  $(".hidden").mouseenter(function() {
    $(".level-1").slideDown();
  });
  $(".level-1 .inner").mouseenter(function() {
    $(".level-2").slideDown();
  });
  $(".level-2 .inner").mouseenter(function() {
    $(".level-3").slideDown();
  });
  $(".level-3 .inner").mouseenter(function() {
    $(".level-4").slideDown();
  });
  $(".level-4").mouseenter(function() {
    $(".level-4").show();
  });
  $(".level-1").mouseleave(function() {
    $(".level-1").slideUp();
  });
  $(".level-2").mouseleave(function() {
    $(".level-2").slideUp();
  });
  $(".level-3").mouseleave(function() {
    $(".level-3").slideUp();
  });
  $(".level-4").mouseleave(function() {
    $(".level-4").slideUp();
  });
  $("#grid").click(function() {
    $(".item").removeClass("col-md-12 col-lg-12 col-xl-12 cell");
    $(".item").addClass("col-md-6 col-lg-3 col-xl-3");
  });
  $("#table").click(function() {
    $(".item").removeClass("col-md-6 col-lg-3 col-xl-3");
    $(".item").addClass("col-md-12 col-lg-12 col-xl-12 cell");
  });
  $(function() {
    $(".row").sortable();
    $(".row").disableSelection();
  });
  $(".up").hide();
  $("h3").click(function() {
    $(".up").fadeIn();
  });
  $(":submit").click(function() {
    $(".up").fadeOut();
  });
});