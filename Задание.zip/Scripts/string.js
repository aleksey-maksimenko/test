/** @var {{BracesString: {GenBracesString: {}}}} N*/
N._INIT_('BracesString.GenBracesString');
(function() {
    for (var __ClassName in this) {
        if (__ClassName === 'class') continue;
        eval("var " + __ClassName + " = this." + __ClassName + ";");
    }
    var genString = this.genString = function(
        bracesCount) {
        bracesCount = parseInt(bracesCount);
        var firstPartOpen;
        firstPartOpen = {};
        var firstPartClose;
        firstPartClose = {};
        var secondPartOpen;
        secondPartOpen = {};
        var secondPartClose;
        secondPartClose = {};
        var i;
        __loop1:
            for (i = 1; i <= bracesCount; i++) {
                if (!isEven(i)) {
                    firstPartOpen[] = getBrace(i, "open");
                    firstPartClose[] = getBrace(i, "close");
                } else {
                    secondPartOpen[] = getBrace(i, "open");
                    secondPartClose[] = getBrace(i, "close");
                }
            }
        var firstPartString;
        firstPartString = implode(firstPartOpen).implode(array_reverse(firstPartClose));
        var secondPartString;
        secondPartString = implode(secondPartOpen).implode(array_reverse(secondPartClose));
        return firstPartString.secondPartString;
    };
    var isEven = this.isEven = function(
        num) {
        return num % 2 == 0;
    };
    var getBrace = this.getBrace = function(
        braceIndex, open) {
        braceIndex = braceIndex > 6 ? braceIndex % 6 : braceIndex;
        var braces;
        braces = {
            "1": {
                "open": "(",
                "close": ")"
            },
            "2": {
                "open": "(",
                "close": ")"
            },
            "3": {
                "open": "{",
                "close": "}"
            },
            "4": {
                "open": "{",
                "close": "}"
            },
            "5": {
                "open": "[",
                "close": "]"
            },
            "6": {
                "open": "[",
                "close": "]"
            }
        };
        return braces[braceIndex][open];
    };
}).call(N.BracesString.GenBracesString);
