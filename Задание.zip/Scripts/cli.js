/** @var {{BracesString: {Cli: {}}}} N*/
N._INIT_('BracesString.Cli');
(function() {
    for (var __ClassName in this) {
        if (__ClassName === 'class') continue;
        eval("var " + __ClassName + " = this." + __ClassName + ";");
    }
    var Docopt = N.Docopt;
    var genString = N.BracesString.GenBracesString.genString;
    // phpcs:disable
    var DOC = "Usage:\n\
  bin/getBracesString (-h|--help)\n\
  bin/getBracesString <bracesCount>\n\
\n\
Options:\n\
  -h --help     	Show this screen\n\
";
    this.DOC = DOC;
    // phpcs:enable
    var run = this.run = function() {
        var handle;
        handle = Docopt.handle(DOC);
        var bracesCount;
        bracesCount = handle.args["<bracesCount>"];
        console.log(genString(bracesCount).PHP_EOL);
    };
}).call(N.BracesString.Cli);
